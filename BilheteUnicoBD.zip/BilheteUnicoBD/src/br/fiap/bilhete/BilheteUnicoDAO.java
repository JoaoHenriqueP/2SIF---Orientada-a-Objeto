package br.fiap.bilhete;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fiap.conexao.Conexao;
import br.fiap.usuario.Usuario;
import br.fiap.usuario.UsuarioDAO;

public class BilheteUnicoDAO {

	private PreparedStatement ps;
	private Connection conexao;
	private ResultSet rs;
	private String sql;

	public BilheteUnicoDAO() {
		conexao = new Conexao().conectar();
	}

	public BilheteUnico pesquisarCPF(String cpf) {
		BilheteUnico bilhete = null;
		String sql = "select * from java_bilhete where cpf=?";

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, cpf);
			rs = ps.executeQuery();
			if (rs.next()) {
				bilhete = new BilheteUnico(rs.getInt("numero"), rs.getString("cpf"), rs.getDouble("saldo"));
			}
		} catch (SQLException e) {
			System.out.println("Problema em pesquisar bilhete pelo cpf!!" + e);
		}

		return bilhete;
	}

	public boolean pesquisarBilhete(int bilhete) {
		boolean result = false;
		String sql = "select numero from java_bilhete where numero=?";

		try {
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, bilhete);
			rs = ps.executeQuery();
			result = rs.next();
		} catch (SQLException e) {
			System.out.println("Problema em pesquisar bilhete pelo numero!!" + e);
		}

		return result;
	}

	public boolean emitirBilhete(Usuario usuario, BilheteUnico bilhete) {
		sql = "insert into java_bilhete(numero,cpf,saldo,valorPassagem) values(?,?,?,?)";
		try {
			new UsuarioDAO().inserir(usuario.getNome(), usuario.getCpf(), usuario.getTarifa());
			ps = conexao.prepareStatement(sql);
			ps.setInt(1, bilhete.getNumero());
			ps.setString(2, usuario.getCpf());
			ps.setDouble(3, bilhete.getSaldo());
			ps.setDouble(4, bilhete.valorDaPassagem);
			ps.execute();
		} catch (SQLException e) {
			System.out.println("Problema em inserir um bilhete!!" + e);
		}

		return false;
	}

}
