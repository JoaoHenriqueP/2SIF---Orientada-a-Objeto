package br.fiap.bilhete;

public class BilheteUnico {

	private int numero;
	private String cpfUsuario;
	private double saldo;
	public static final double valorDaPassagem = 4.40;
	
	public BilheteUnico(String cpfUsuario) {
		this.cpfUsuario = cpfUsuario;
	}
	
	public void passarNaCatraca() {
		saldo -= valorDaPassagem;
	}
	public void carregar(double valor) {
		saldo += valor;
	}

	public String getCpfUsuario() {
		return cpfUsuario;
	}

	public void setCpfUsuario(String cpfUsuario) {
		this.cpfUsuario = cpfUsuario;
	}

	public BilheteUnico(int numero, String cpfUsuario, double saldo) {
		this.numero = numero;
		this.cpfUsuario = cpfUsuario;
		this.saldo = saldo;
	}

	public int getNumero() {
		return numero;
	}


	public void setNumero(int numero) {
		this.numero = numero;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	@Override
	public String toString() {
		String aux;
		aux = "CPF: " + cpfUsuario + "\n";
		aux += "Numero: " + numero + "\n";
		aux += "Saldo: " + String.format("%.2f", saldo) + "\n";
		return aux;
	}
	
	
	
}
