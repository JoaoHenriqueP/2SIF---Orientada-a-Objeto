package br.fiap.usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fiap.conexao.Conexao;

public class UsuarioDAO {

	private PreparedStatement ps;
	private Connection conexao;
	private ResultSet rs;
	private String sql;

	public UsuarioDAO() {
		conexao = new Conexao().conectar();
	}

	public boolean inserir(String nome, String cpf, String tipo) {
		boolean result = false;
		sql = "insert into java_usuario values(?,?,?)";

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, nome);
			ps.setString(2, cpf);
			ps.setString(3, tipo);
			ps.execute();
		} catch (SQLException e) {
			System.out.println("Problema em inserir um usuario!!" + e);
		}

		return result;
	}

}
