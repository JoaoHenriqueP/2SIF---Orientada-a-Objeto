package br.fiap.form;
import static javax.swing.JOptionPane.*;

import br.fiap.bilhete.BilheteUnico;
import br.fiap.bilhete.BilheteUnicoDAO;

import static java.lang.Integer.parseInt;

public class FormPrincipal {

	
	public void menuPrincipal() {
		String opcao;
		do {
			opcao = showInputDialog("Digite sua senha ou CPF ou Sair");
			if (opcao.equalsIgnoreCase("admin")) {
				new FormAdmin().menuAdmin();
			} else if (!opcao.equalsIgnoreCase("sair")) {
				BilheteUnico bilhete = new BilheteUnicoDAO().pesquisarCPF(opcao);
				String aux ="CPF: "+ bilhete.getCpfUsuario();
				aux += "\n  Numero: " + bilhete.getNumero();
				aux += "\n  Saldo: " +bilhete.getSaldo();
				showMessageDialog(getRootFrame(), aux);
				//System.out.println("CPF:"+ bilhete.getCpfUsuario() + "\n  Numero:" +bilhete.getNumero() + "\n  Saldo:" +bilhete.getSaldo());
				
				
			}
		} while(!opcao.equalsIgnoreCase("sair"));		
	}
	
}
