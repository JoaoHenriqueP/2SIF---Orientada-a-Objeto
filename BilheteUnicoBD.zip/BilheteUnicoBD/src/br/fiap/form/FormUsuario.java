package br.fiap.form;

import static java.lang.Integer.parseInt;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import br.fiap.bilhete.BilheteUnico;
import br.fiap.bilhete.BilheteUnicoDAO;

public class FormUsuario {

	public void menuUsuario(BilheteUnico bilhete) {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenuUsuario()));
				switch (opcao) {
				case 1:
					carregar(bilhete.getCpfUsuario());
					break;
				case 2:
					break;
				case 3:
					break;
				default:
					break;
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A opção deve ser um número");
			}

		} while (opcao != 4);

	}
	
	private void carregar(String cpf) {
		BilheteUnicoDAO dao = new BilheteUnicoDAO();
		double valor = Double.parseDouble(showInputDialog("Digite o valor que deseja inserir:"));
		System.out.println("1");
		double valorAntes = dao.pesquisarCPF(cpf).getSaldo();
		System.out.println("2");
		dao.carregar(cpf, valorAntes+valor);
		System.out.println("3");
	}

	private String gerarMenuUsuario() {
		String menu = "Escolha uma operação:\n";
		menu += "1. Carregar Bilhete\n";
		menu += "2. Passar na Catraca\n";
		menu += "3. Consultar Saldo\n";
		menu += "4. Sair";
		return menu;
	}

}
