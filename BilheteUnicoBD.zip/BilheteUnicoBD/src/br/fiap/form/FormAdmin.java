package br.fiap.form;

import static javax.swing.JOptionPane.*;

import java.util.Random;

import javax.swing.JOptionPane;

import br.fiap.bilhete.BilheteUnico;
import br.fiap.bilhete.BilheteUnicoDAO;
import br.fiap.usuario.Usuario;

import static java.lang.Integer.parseInt;

public class FormAdmin {

	public void menuAdmin() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenuAdmin()));
				switch (opcao) {
				case 1:
					emitirBilhete();
					break;

				default:
					break;
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A opção deve ser um número");
			}
			;

		} while (opcao != 4);

	}

	private void emitirBilhete() {
		BilheteUnicoDAO dao = new BilheteUnicoDAO();
		Random gerador = new Random();
		String cpf;
		int numero, tipo;
		String nome;
		String tarifa[] = { "Estudante", "Professor", "Normal" };
		cpf = showInputDialog("Digite seu cpf:");
		if (dao.pesquisarCPF(cpf) == null) {
			do {
				numero = gerador.nextInt(1000, Integer.MAX_VALUE);
			} while (dao.pesquisarBilhete(numero));
			nome = showInputDialog("Nome do usuário:");
			tipo = showOptionDialog(null, "Tipo de tarifa:", "Tipo de tarifa", 0, 0, null, tarifa, tarifa[0]);
			Usuario usuario = new Usuario(nome, cpf, tarifa[tipo]);
			BilheteUnico bilhete = new BilheteUnico(numero, cpf, 0);
			dao.emitirBilhete(usuario, bilhete);
		} else {
			showMessageDialog(null, "Usuário já cadastrado!");
		}

	}

	private String gerarMenuAdmin() {
		String menu = "Escolha uma operação:\n";
		menu += "1. Emitir Bilhete\n";
		menu += "2. Imprimir Bilhete\n";
		menu += "3. Consultar Bilhete\n";
		menu += "4. Sair";
		return menu;

	}

}
