
public class Main {

	public static void main(String[] args) {

		
		Aluno aluno = new Aluno("Henry", 2);
		AlunoDAO dao = new AlunoDAO();
		dao.inserir(aluno);
		
		//System.out.println(dao.pesquisar(1));
	}
}
