package br.fiap.usuario;

public class Usuario {
	
	private String nome;
	private String cpf;
	private String tarifa;
	
	public Usuario(String nome, String cpf, String tarifa) {
		this.nome = nome;
		this.cpf = cpf;
		this.tarifa = tarifa;
	}
	
	

}
