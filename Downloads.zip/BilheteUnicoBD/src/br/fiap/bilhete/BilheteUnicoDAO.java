package br.fiap.bilhete;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fiap.conexao.Conexao;

public class BilheteUnicoDAO {

	private PreparedStatement ps;
	private Connection conexao;
	private ResultSet rs;
	private String sql;

	public BilheteUnicoDAO() {
		conexao = new Conexao().conectar();
	}

	public BilheteUnico pesquisarCPF(String cpf) {
		BilheteUnico bilhete = null;
		String sql = "select * from java_bilhete where cpf=?";
		
		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, cpf);
			rs = ps.executeQuery();
			if(rs.next()) {
				bilhete = new BilheteUnico(rs.getInt("numero"), rs.getString("cpf"),rs.getDouble("saldo"));
			}
		} catch (SQLException e) {
			System.out.println("Problema em pesquisar bilhete pelo cpf!!" + e);
		}
		
		return bilhete;
	}
	
	//PROFESSOR PAROU AQUI
	
	public boolean inserir(String cpf) {
		sql = "insert into java_bilhete(cpf) values(?)";

		try {
			ps = conexao.prepareStatement(sql);
			ps.setString(1, cpf);
			ps.execute();
		} catch (SQLException e) {
			System.out.println("Problema em inserir um aluno!!" + e);
		}

		return false;
	}

	public ResultSet imprimir() {

		try {
			ps = conexao.prepareStatement(sql);
			rs = ps.executeQuery();
			rs.next();
		} catch (SQLException e) {
			System.out.println("Problema em inserir um aluno!!" + e);
		}
		return rs;
	}
}
